function str_rand() {
    var result       = '';
    var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
    var max_position = words.length - 1;
        for( i = 0; i < 7; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
    return result;
}

const{Builder, By} = require("selenium-webdriver");
async function registrationAndLogin(){
    let driver = await new Builder().forBrowser("chrome").build();
    await driver.get("https://www.elephantstock.com/");
    await driver.sleep(5000);

    driver.findElement(By.xpath("/html/body/div[11]/div[1]/span")).click();
    await (await driver.findElement(By.xpath("/html/body/header/div[1]/div/div/span[3]/a[2]"))).click();
    await (await driver.findElement(By.id("customer_register_link"))).click(); 

    let fName = str_rand();
    let lName = str_rand();
    let mail = str_rand();
    let pass = str_rand();
    driver.sleep(5000);

     driver.findElement(By.id("FirstName")).sendKeys(fName);
    driver.findElement(By.id("LastName")).sendKeys(lName);
    driver.findElement(By.id("Email")).sendKeys(mail+"@gmail.com");
    driver.findElement(By.id("CreatePassword")).sendKeys(pass);
     driver.findElement(By.xpath("/html/body/div[6]/main/div/div/div/div/div/div/form/p[2]/input")).click();
    //-----log Out-----
    driver.sleep(8000);
     driver.findElement(By.xpath("/html/body/header/div[1]/div/div/span[3]/a[2]")).click();
    driver.sleep(5000);
     driver.findElement(By.id("account_details-li")).click();
     driver.findElement(By.xpath("/html/body/div[6]/main/div/div/div/div/div/div/div[4]/div/a")).click();
    driver.sleep(5000)
    //-----log in----
    await (await driver.findElement(By.xpath("/html/body/header/div[1]/div/div/span[3]/a[2]"))).click();
    driver.findElement(By.id("CustomerEmail")).sendKeys(mail+"@gmail.com");
    driver.findElement(By.id("CustomerPassword")).sendKeys(pass);
    await (await driver.findElement(By.xpath("/html/body/div[6]/main/div/div/div/div[2]/form/p[2]/input"))).click();
}
registrationAndLogin();