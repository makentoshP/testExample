function str_rand() {
    var result       = '';
    var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
    var max_position = words.length - 1;
        for( i = 0; i < 7; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
    return result;
}

const{Builder, By, Key, until, WebElement} = require("selenium-webdriver");
async function example(){
    let driver = await new Builder().forBrowser("chrome").build();
    await driver.get("https://www.elephantstock.com/");
    await driver.sleep(5000);
    driver.findElement(By.xpath("/html/body/div[11]/div[1]/span")).click();
    await (await driver.findElement(By.xpath("/html/body/header/div[1]/div/div/span[3]/a[2]"))).click();
    await (await driver.findElement(By.id("customer_register_link"))).click(); 
    await driver.findElement(By.id("FirstName")).sendKeys("qwerqwer");
    driver.findElement(By.id("FirstName")).sendKeys(str_rand());
    driver.findElement(By.id("LastName")).sendKeys(str_rand());
    driver.findElement(By.id("Email")).sendKeys(str_rand()+"@gmail.com");
    driver.findElement(By.id("CreatePassword")).sendKeys(str_rand());
    (await driver.findElement(By.xpath("/html/body/div[6]/main/div/div/div/div/div/div/form/p[2]/input"))).click();
}
example();